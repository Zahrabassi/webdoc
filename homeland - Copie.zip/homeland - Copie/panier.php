<?php require 'header.php' ;?>
<?php
if (isset($_GET['del']))
{
$panier->del($_GET['del']);
}
 ?>
<meta charset="utf-8">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
   <link rel="stylesheet" type="text/css" href="panier.css">
  <script language="javascript" type="text/javascript" src="panier.js"></script>

<body>
  <main>
    <div class="basket">
    <div class="basket-module">
    </br>
        </br>

    </br>

    </br>
    <label for="promo-code">Enter a promotional code</label>
    <input id="promo-code" type="text" name="promo-code" maxlength="5" class="promo-code-field">
    <button class="promo-code-cta">Apply</button>
    </div>
    <div class="basket-labels">

        <ul>
          <li class="item item-heading">Item</li>
          <li class="price">Price</li>
          <li class="quantity">Quantity</li>
          <li class="subtotal">Subtotal</li>
        </ul>
    </div>
        <?php 
$ids=array_keys($_SESSION['panier']);
if(empty($ids))
{
  $products = array();
}else{
  $products=$DB->query('SELECT * FROM produit_panier WHERE id IN ('.implode(',',$ids).')');

}
foreach ($products as $product):
 ?>



      <div class="basket-product">

      <div class="item">
      <div class="product-image">
      <img src="images/<?= $product->id ;?>.jpg"
       alt="Placholder Image 2" class="product-frame">
      </div>
      <div class="product-details">
      <h1><strong><span class="item-quantity"></span> <?php echo $product->nom; ?></strong></h1>
      <p><strong><?php echo $product->adresse; ?></strong></p>
      </div>
      </div>
      <div class="price"><?= number_format($product->prix,3,',',' '); ?></div>
              <form method="post" action="panier.php">
      <span class="quantity"><input type="text" name="panier[quantity][<?= $product->id; ?>]" value="<?=$_SESSION['panier'][$product->id] ;?>" ></span>
      <div class="subtotal"><?= number_format($product->prix *1.18,3,',',' '); ?></div>
      <input type="submit" value="recalculer">
      </form>
      <span class="remove"><a href="panier.php?delpanier=<?= $product->id ; ?>"> <button style="color: black;">Remove </button> </a></span>
      </div>
      <?php endforeach ; ?>
    </div>
    <aside>
      <div class="summary">
        <div class="summary-total-items"><span class="total-items"></span> Items in your Bag</div>
        
        
        <div class="summary-total">
          <div class="total-title">Total</div>
          <div class="total-value final-value" id="basket-total">
            <?=number_format($panier->total() *1.18,3,',',' '); ?>£
          </div>
        </div>
        <div class="summary-checkout">
           <a href="login_form.php"><button class="checkout-cta">Go to Secure Checkout</button></a>
        </div>

      </div>
    </aside>
  </main>
<?php require 'footer.php'; ?>



















