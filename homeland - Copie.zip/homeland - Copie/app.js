(function($)
{
$('.addPanier').click(function(event)
{
 event.preventDefault();
});
})(jQuery);