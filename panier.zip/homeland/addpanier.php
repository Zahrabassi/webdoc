<?php require '_header.php';
if (isset($_GET['id'])){
	$product=$DB->query('SELECT id FROM produit_panier WHERE id=:id', array('id' =>$_GET['id']));
	if(empty($product)){
		die("Ce produit n'existe pas");
	}
	$panier->add($product[0]->id);
	die('le produit a  bien été ajouter à votre panier <a href="javascript:history.back();">retourner sur le catalogue');

}else{
	die("vous navez pas selectionné un produit a ajouter au panier");
}






