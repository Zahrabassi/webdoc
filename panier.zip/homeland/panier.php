<?php require 'header.php' ;?>
<?php
if (isset($_POST['del']))
{
$panier->del($_POST['del']);
}
 ?>

<?php
if(isset($_POST['search']))
{
    $valueToSearch1 = $_POST['value_To_Search'];
    // search in all table columns
    // using concat mysql function
    $query = "SELECT * FROM `produit_panier` WHERE CONCAT(`id`, `nom`, `adresse`, `prix`,'description') LIKE '%".$valueToSearch1."%'";
    $search_result = filterTable($query);
    
}
 else {
    $query = "SELECT * FROM `produit_panier`";
    $search_result = filterTable($query);
}

// function to connect and execute the query
function filterTable($query)
{
    $connect = mysqli_connect("localhost", "root", "", "projet");
    $filter_Result = mysqli_query($connect, $query);
    return $filter_Result;
}

?>
<meta charset="utf-8">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
   <link rel="stylesheet" type="text/css" href="panier.css">
  <script language="javascript" type="text/javascript" src="panier.js"></script>

<script language="javascript">
    function print(pdf) {
        // Créer un IFrame.
        var iframe = document.createElement('iframe');  
        // Cacher le IFrame.    
        iframe.style.visibility = "hidden"; 
        // Définir la source.    
        iframe.src = pdf;        
        // Ajouter le IFrame sur la page Web.    
        document.body.appendChild(iframe);  
        iframe.contentWindow.focus();       
        iframe.contentWindow.print(); // Imprimer.
    }
</script>  

<body>
  <main>
    <div class="basket">
    <div class="basket-module" name="iframe">
    </br>
        </br>

    </br>

    </br>
    <form method="post" action="panier.php">
    <label for="promo-code">Value To Search</label>
    <input id="promo-code" type="text"  name="value_To_Search" maxlength="5" class="promo-code-field">
    <button class="promo-code-cta" name="search">Apply</button>
    </div>
    <div class="basket-labels">
        <ul>
          <li class="item item-heading">Item</li>
          <li class="price">Price</li>
          <li class="quantity">Quantity</li>
          <li class="subtotal">Subtotal</li>
        </ul>
    </div>

<?php 
$ids=array_keys($_SESSION['panier']);
if(empty($ids))
{
  $products = array();
}else{
  $products=$DB->query('SELECT * FROM produit_panier WHERE id IN ('.implode(',',$ids).')');

}
sort($products);

foreach ($products as $product):?>
      <div class="basket-product">
      <div class="item">
      <div class="product-image">
      <img src="images/<?= $product->id ;?>.jpg"
       alt="Placholder Image 2" class="product-frame">
      </div>
      <div class="product-details">
      <h1><strong><span class="item-quantity"></span> <?php echo $product->nom; ?></strong></h1>
      <p><strong><?php echo $product->adresse; ?></strong></p>
      </div>
      </div>
      <div class="price"><?= number_format($product->prix,3,',',' '); ?></div>
      <span class="quantity"><input type="text" name="panier[quantity][<? =$product->id; ?>]" value="<?=$_SESSION['panier'][$product->id] ;?>" ></span>
      <div class="subtotal"><?= number_format($product->prix *1.18,3,',',' '); ?></div>
      <span class="remove"><a href="panier.php?del=<?= $product->id; ?>"> <button style="color: black;">Remove </button> </a></span>
      </div>
      <body>
    <button onclick="print('https://waytolearnx.com/test.pdf')">Imprimer le PDF</button>
      <input type="submit" value="recalculer">
      </form>
    <?php endforeach ; ?>
    </div>
    <aside>
      <div class="summary">
        <div class="summary-total-items"><span class="total-items"></span> Items in your Bag</div>
        <div class="summary-subtotal">
          <div class="summary-promo hide">
            <div class="promo-title">Promotion</div>
            <div class="promo-value final-value" id="basket-promo"></div>
          </div>
          
        </div>
        <div class="summary-delivery">
          <select name="delivery-collection" class="summary-delivery-selection">
              <option value="0" selected="selected">Select Collection or Delivery</option>
             <option value="collection">Collection</option>
             <option value="first-class">Royal Mail 1st Class</option>
             <option value="second-class">Royal Mail 2nd Class</option>
             <option value="signed-for">Royal Mail Special Delivery</option>
          </select>
        </div>
        <div class="summary-total">
          <div class="total-title">Total</div>
          <div class="total-value final-value" id="basket-total">
            <?=number_format($panier->total() *1.18,3,',',' '); ?>£
          </div>
        </div>
        <div class="summary-checkout">
         <a href="login_form.php"> <button class="checkout-cta">Go to Secure Checkout</button></a>
        </div>



      </div>
    </aside>

  </main>
  <?php while($row = mysqli_fetch_array($search_result)):?>
  <table>
                <tr>
                    <td><?php echo $row['id'];?></td>
                    <td><?php echo $row['nom'];?></td>
                    <td><?php echo $row['adresse'];?></td>
                    <td><?php echo $row['prix'];?></td>
                </tr>
                <?php endwhile;?>
            </table>
        </form>
<?php require 'footer.php'; ?>


















