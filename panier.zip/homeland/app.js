(function ($) {
	

$('.addPanier1').click(function(event)){
	event.preventDefault();
	return false;
};
})(jQuery);