<?php
class panier
{
	
private $DB;


	 public function __construct($DB)
	{
		if(!isset($_SESSION))
		{
			session_start();
		}
		if(!isset($_SESSION['panier']))
		{
			$_SESSION['panier'] = array();
		}
		$this->DB= $DB;
		if (isset($_POST['delpanier'])) {
			$this->del($_POST['delpanier']);
		}
		if (isset($_POST['panier']['quantity'])) {
			$this->recalc();
		}
	}

	public function total()
	{
		$total=0;
		$ids=array_keys($_SESSION['panier']);
        if(empty($ids)){
        $products = array();
    }
    else{
         $products=$this->DB->query('SELECT id,prix FROM produit_panier WHERE id IN ('.implode(',',$ids).')');
     }

		foreach ($products as $product)
		 {
		$total +=$product->prix * $_SESSION['panier'][$product->id];
		}
		return $total;
	}


public function add($product_d)
{
	if (isset($_SESSION['panier'][$product_d])) {
       
       $_SESSION['panier'][$product_d]++;	
   }else
   {
   	       $_SESSION['panier'][$product_d] =1;	

   }
	
}

public function del($product_id){
	
unset($_SESSION['panier'][$product_id]);
}



public function recalc()
{
	foreach ($_SESSION['panier'] as $product_id => $quantity) 
	{
if (isset($_POST['panier']['quantity'][$product_id])) 
{
		$_SESSION['panier'] = $_POST['panier']['quantity'];
	}	
}
	
}
}