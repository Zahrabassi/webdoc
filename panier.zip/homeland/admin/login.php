
<?php
session_start();
require_once "config.php";
if(!empty($_POST["email"])) {
	$conn = mysqli_connect("localhost", "root", "", "projet");
	$sql = "Select * from admin where email = '" . $_POST["email"] . "'";
        if(!isset($_COOKIE["member_login"])) {
            $sql .= " AND password = '" . md5($_POST["password"]) . "'";
	}
        $result = mysqli_query($conn,$sql);
	$user = mysqli_fetch_array($result);
	if($user) {
			$_SESSION["id"] = $user["id"];
			
			if(!empty($_POST["remember"])) {
				setcookie ("member_login",$_POST["email"],time()+ (10 * 365 * 24 * 60 * 60));
			} else {
				if(isset($_COOKIE["member_login"])) {
					setcookie ("member_login","");
				}
			}
	} else {
		$message = "Invalid Login";
	}
}
?>
<?php include "./templates/top.php"; ?>
<?php include "./templates/navbar.php"; ?>
<div class="container">
	<div class="row justify-content-center" style="margin:100px 0;">
		<div class="col-md-4">
			<h4>Admin Login</h4>
			<p class="message"></p>
			<form id="admin-login-form">
			  <div class="form-group">
			    <label for="email">Email address</label><span id="userEmail-info" class="info"></span>
			    <input type="email" class="form-control" name="email" id="email"  placeholder="Enter email" value="<?php if(isset($_COOKIE["member_login"])) { echo $_COOKIE["member_login"]; } ?>">
			    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
			  </div>
			  <div class="form-group">
			    <label for="password">Password</label><span id="userName-info" class="info"></span><br>
			    <input type="password" class="form-control" name="password" id="password" placeholder="Password">
			  </div>
			  <input type="hidden" name="admin_login" value="1">
			  <div class="field-group">
		<div><input type="checkbox" name="remember" id="remember" <?php if(isset($_COOKIE["member_login"])) { ?> checked <?php } ?> />
		<label for="remember-me">Remember me</label>
	</div>
<form action="process.php" method="post" onsubmit="return validateContact();">
    <!-- Google reCAPTCHA widget -->
            <div class="g-recaptcha" data-sitekey="YOUR-SITE-KEY" data-badge="inline" data-size="invisible" data-callback="setResponse"></div><br>
            <input type="hidden" id="captcha-response" name="captcha-response" />
        </form>
        </div>


			  <button type="button" name="submit" class="btn btn-primary login-btn">Submit</button>
			</form>
		</div>
	</div>
</div>

<?php include "./templates/footer.php"; ?>

<script type="text/javascript" src="./js/main.js"></script>
