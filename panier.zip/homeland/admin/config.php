<?php 
define("SITE_KEY", "YOUR_SITE_KEY");
define("SECRET_KEY", "YOUR_SECRET_KEY");
?>